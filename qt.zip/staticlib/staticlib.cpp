#include "staticlib.h"

Staticlib::Staticlib()
{
}
