#ifndef STATICLIB_H
#define STATICLIB_H

class Staticlib
{
public:
    Staticlib();
};

#endif // STATICLIB_H
